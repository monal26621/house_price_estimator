from flask import Flask, render_template, request
import numpy as np
import pickle

# Load trained model
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

# Load scaler
with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

# Initialize Flask app
app = Flask(__name__)

# Home route
@app.route('/')
def home():
    return render_template("index.html")

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():

    area = float(request.form['area'])
    bedrooms = int(request.form['bedrooms'])
    bathrooms = int(request.form['bathrooms'])
    floors = int(request.form['floors'])
    parking = int(request.form['parking'])
    location = int(request.form['location'])

    features = np.array([
        [area, bedrooms, bathrooms, floors, parking, location]
    ])

    scaled_features = scaler.transform(features)

    prediction = model.predict(scaled_features)

    output = round(prediction[0], 2)

    return render_template(
        'index.html',
        prediction_text=f"Estimated House Price: ₹ {output}"
    )

if __name__ == "__main__":
    app.run(debug=False)